import nodemailer from 'nodemailer';
import fs from 'fs';
import { promisify } from 'util';
import pdf from 'html-pdf';
import Handlebars from 'handlebars';
import { fileURLToPath } from 'url';
import path, { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const readFile = promisify(fs.readFile);
const templatePath = path.join(__dirname, 'pdf-template.html');
const writeFile = promisify(fs.writeFile);

export async function sendEmailWithPDF(data) {
  // Create a transporter
  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
      user: 'mithunkumar1944@gmail.com',
      pass: 'adaa lujc qure kpjo'
    }
  });

  const fromMail = "mithunkumar1944@gmail.com";

  // Function to generate PDF from HTML
  const generatePDF = async (data) => {
    const templateHtml = await readFile(templatePath, 'utf8');
    const template = Handlebars.compile(templateHtml);
    let totalCost = 0;
    let tempData = data.furnitures.filter((item) => item.quantity > 0).map((furniture) => {
      totalCost += furniture.quantity * furniture.price;
      return { ...furniture, totalPrice: furniture.quantity * furniture.price }
    })
    if (data.singleLayerPacking) {
      totalCost += 799
    }
    if (data.multiLayerPacking) {
      totalCost += 1599
    }
    if (data.unpacking) {
      totalCost += 799
    }
    if (data.dismantling) {
      totalCost += 799
    }
    let pdfData = { ...data, furnitures: tempData, totalCost: totalCost };
    console.log('pdfData::', pdfData);
    const html = template(pdfData);
    const pdfPath = 'details.pdf';

    return new Promise((resolve, reject) => {
      pdf.create(html, {}).toFile(pdfPath, (err, res) => {
        if (err) {
          reject(err);
        } else {
          resolve(pdfPath);
        }
      });
    });
  };

  // Generate the PDF
  const pdfPath = await generatePDF(data);

  // Define mail options
  let mailOptions = {
    from: fromMail, // Replace with your email
    to: `${fromMail}, ${data.email}`, // Replace with recipient email
    subject: 'Moving Details',
    text: 'Please find the attached PDF for moving details.',
    attachments: [
      {
        filename: 'details.pdf',
        path: pdfPath,
        contentType: 'application/pdf'
      }
    ]
  };

  // Send email
  try {
    await transporter.sendMail(mailOptions);
    console.log('Email sent successfully');
    return true;
  } catch (error) {
    console.error('Error sending email:', error);
  } finally {
    // Clean up the generated PDF file
    fs.unlinkSync(pdfPath);
    return false;
  }
}