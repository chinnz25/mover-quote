import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import logger from "./logger.js";
import notFoundController from "./routes/notFoundController.js";
import packingFormContainer from "./routes/formRoute.js"
// import authenticateMiddleware from "./middlewares/authenticateMiddleware.js";

dotenv.config();
dotenv.config({ path: `.env.${process.env.NODE_ENV}` });

const app = express();

logger.info(`NODE_ENV = ${process.env.NODE_ENV}`);
logger.info(`APP_VERSION = ${process.env.APP_VERSION}`);

// Handle uncaught exceptions
process.on("uncaughtException", (error) => {
    logger.error("Uncaught Exception:", error);
});

// Handle unhandled promise rejections
process.on("unhandledRejection", (error) => {
    logger.error("Unhandled Promise Rejection:", error);
});

// Use bodyParser middleware to parse JSON and URL-encoded data
app.use(bodyParser.json({ limit: "10mb" }));
app.use(bodyParser.urlencoded({ extended: true, limit: "10mb" }));

// Use cors middleware to handle Cross-Origin Resource Sharing
app.use(cors());

// Other middleware and configurations
morgan.token("body", (req, res) => {
    let body = req.body;
    if (JSON.stringify(body).length > 2) {
        if (body.expenseAttachments) {
            body.expenseAttachments.forEach((element, index) => {
                body.expenseAttachments[index].base64Image = "Base64String";
            });
        }
        return JSON.stringify(body);
    }
});

morgan.token("fullUrl", (req, res) => {
    return `${req.protocol}://${req.get("host")}${req.originalUrl}`;
});

app.use(
    morgan(":method Request :fullUrl :body :status Response length :res[content-length] - :response-time ms", {
        stream: {
            write: (message) => {
                logger.info(`${message.trim()}\n------------------------------------------------------`);
            },
        },
    })
);

// Routes
// app.use(authenticateMiddleware);
app.use("/api/packing/", packingFormContainer);
app.use("*", notFoundController);

const PORT = process.env.EXPOSE_PORT;

app.listen(PORT, process.env.IDENTITY_ISSUER_URL, () => {
    logger.info(`Server is running at http://${process.env.IDENTITY_ISSUER_URL}:${PORT} - ${process.env.NODE_ENV}`);
});
