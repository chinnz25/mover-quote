import { fileURLToPath } from "url";
import logger from "../logger.js";
import { notFound } from "../utilities/apiResponse.js";

const __filename = fileURLToPath(import.meta.url);

const notFoundController = async (req, res) => {
  let resObj;
  try {
    logger.info("Page not found : URL is not defined", { file: __filename });
    resObj = notFound("Page not found");
  } catch (error) {
    logger.error(error, { file: __filename });
    resObj = internalServerError();
  }
  logger.info("Response body : " + JSON.stringify(resObj), { file: __filename });
  res.status(resObj.resultCode).json(resObj);
};

export default notFoundController;
