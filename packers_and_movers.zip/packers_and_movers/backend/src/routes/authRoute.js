import express from "express";
import authenticateMiddleware from "../middlewares/authenticateMiddleware.js";
import {
  register,
  getAllUserPageDetails,
  login,
  verifyEmail,
  forgetPassword,
  changePassword,
} from "../controllers/authController.js";

const router = express.Router();

router.route("/register").post(authenticateMiddleware, register);

router.route("/initial/:id").get(authenticateMiddleware, getAllUserPageDetails);

router.route("/login").post(login);

router.route("/verify-email").post(verifyEmail);

router.route("/forget-password").post(forgetPassword);

router.route("/change-password").post(changePassword);

export default router;
