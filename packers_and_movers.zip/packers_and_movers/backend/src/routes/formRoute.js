import express from "express";
import { postPackingDetails, getLocation } from "../controllers/packingFormController.js";

const router = express.Router();

router.route("/").post(postPackingDetails);
router.route("/location").post(getLocation);

export default router;