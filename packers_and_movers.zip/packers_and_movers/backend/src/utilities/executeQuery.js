import connection from "../database.js";

const executeQuery = (query, values) => {
  return new Promise((resolve, reject) => {
    connection.query(query, values, (error, results) => {
      if (error) {
        return reject(`DB ${error}`);
      }
      resolve(results);
    });
  });
};

export default executeQuery;
