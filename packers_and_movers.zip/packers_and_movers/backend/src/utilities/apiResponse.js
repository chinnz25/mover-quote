import StatusCode from "./statusCode.js";

class ApiResponse {
  constructor(status, data, statusCode, message) {
    this.status = status;
    this.data = data;
    this.resultCode = statusCode;
    this.message = message;
  }
}

/**
 * Creates an instance of ApiResponse with custom parameters.
 *
 * @param {boolean} status - The status of the response (true for success, false for failure).
 * @param {any} data - The data to be included in the response. Can be an array or an object.
 * @param {number} StatusCode - The HTTP status code to be included in the response.
 * @param {string} message - The message associated with the response.
 * @returns {ApiResponse} An instance of ApiResponse with the provided parameters.
 */
export const customized = (status, data, statusCode, message) => {
  return new ApiResponse(status, data, statusCode, message);
};

/**
 * Creates an ApiResponse object for unauthorized responses.
 *
 * @param {string} [message="Unauthorized"] - The error message associated with the unauthorized response. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the unauthorized response.
 */
export const unauthorized = (message = "Unauthorized") => {
  return new ApiResponse(false, null, StatusCode.unauthorized, message);
};

/**
 * Creates an ApiResponse object for success responses.
 *
 * @param {any} data - The data to be included in the response. Can be an array or an object.
 * @param {string} [message="success"] - The error message associated with the success response. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the success response.
 */
export const success = (data, message = "success") => {
  return new ApiResponse(true, data, StatusCode.success, message);
};

/**
 * Creates an ApiResponse object for successful read operations.
 *
 * @param {any} data - The data to be included in the response. Can be an array or an object.
 * @param {string} [message="Read successfully"] - The message associated with the response. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the successful read response.
 */
export const read = (data, message = "Read successfully") => {
  return new ApiResponse(true, data, StatusCode.success, message);
};

/**
 * Creates an ApiResponse object for successful create operations.
 *
 * @param {any} data - The data to be included in the response. Can be an array or an object.
 * @param {string} [message="Created successfully"] - The message associated with the response. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the successful create response.
 */
export const created = (data, message = "Created successfully") => {
  return new ApiResponse(true, data, StatusCode.created, message);
};

/**
 * Creates an ApiResponse object for successful update operations.
 *
 * @param {string} [message="Updated successfully"] - The message associated with the response. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the successful update response.
 */
export const updated = (message = "Updated successfully") => {
  return new ApiResponse(true, null, StatusCode.success, message);
};

/**
 * Creates an ApiResponse object for not modified operations.
 *
 * @param {string} [message="Not modified"] - The message associated with the response. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the not modified response.
 */
export const notModified = (message = "Not modified") => {
  return new ApiResponse(true, null, StatusCode.notModified, message);
};

/**
 * Creates an ApiResponse object for successful delete operations.
 *
 * @param {string} [message="Deleted successfully"] - The message associated with the response. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the successful delete response.
 */
export const deleted = (message = "Deleted successfully") => {
  return new ApiResponse(true, null, StatusCode.success, message);
};

/**
 * Creates an ApiResponse object for not found responses.
 *
 * @param {string} [message="Not found"] - The error message associated with the not found. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the not found response.
 */
export const notFound = (message = "Not found") => {
  return new ApiResponse(false, null, StatusCode.notFound, message);
};

/**
 * Creates an ApiResponse object for conflict operations.
 *
 * @param {string} [message="Conflict"] - The message associated with the response. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the conflict response.
 */
export const conflict = (message = "Conflict") => {
  return new ApiResponse(true, null, StatusCode.conflict, message);
};

/**
 * Creates an ApiResponse object for bad request responses.
 *
 * @param {string} [message="Bad request"] - The error message associated with the bad request. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the bad request response.
 */
export const badRequest = (message = "Bad request") => {
  return new ApiResponse(false, null, StatusCode.badRequest, message);
};

/**
 * Creates an ApiResponse object for internal server error responses.
 *
 * @param {string} [message="Internal server error"] - The error message associated with the bad request. Optional.
 * @returns {ApiResponse} An instance of ApiResponse representing the internal server error response.
 */
export const internalServerError = (message = "Internal server error") => {
  return new ApiResponse(false, null, StatusCode.internalServerError, message);
};
