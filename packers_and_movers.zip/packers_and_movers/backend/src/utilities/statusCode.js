class StatusCode {
  static success = 200;
  static created = 201;
  static resetContent = 205;
  static notModified = 304;
  static badRequest = 400;
  static unauthorized = 401;
  static notFound = 404;
  static conflict = 409;
  static internalServerError = 500;
  static noContent = 204;
}

export default StatusCode;
