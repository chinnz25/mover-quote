import { fileURLToPath } from "url";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import logger from "../logger.js";
import EmailNotificationModel from "../models/emailNotificationModel.js";
import { check, update } from "../services/emailNotificationService.js";

const __filename = fileURLToPath(import.meta.url);

dotenv.config();
dotenv.config({ path: `.env.${process.env.NODE_ENV}` });

export const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_ADDRESS,
    pass: process.env.EMAIL_PASSWORD,
  },
});

const sendEmail = async (mailOptions, emailDetails, retrieveCount) => {
  const id = emailDetails[EmailNotificationModel.emailNotificationId];
  try {
    retrieveCount += 1;
    const emailInfo = await transporter.sendMail(mailOptions);
    if (emailInfo.response) {
      const result = await update({ retryCount: retrieveCount, isSent: true, id });
      if (result === undefined) {
        logger.info("Response data is undefined", { file: __filename }, { file: __filename });
        throw Error(`Result : ${result}`);
      }
      logger.info("Email sent : " + JSON.stringify(emailInfo.response), { file: __filename });
    }
  } catch (error) {
    logger.error("Error sending email : " + JSON.stringify(error));
    const result = await update({ retryCount: retrieveCount, isSent: false, id });
    if (result === undefined) {
      logger.info("Response data is undefined", { file: __filename }, { file: __filename });
    }
    if (retrieveCount < 2) {
      return "retry";
    }
  }
};

const checkAndSendEmail = async () => {
  try {
    const email = await check();
    if (email.status) {
      const result = email.data;
      logger.debug("Result : " + JSON.stringify(result), { file: __filename });
      for (const emailDetails of result) {
        logger.debug("Email Sending.... " + emailDetails[EmailNotificationModel.recipientEmail], { file: __filename });
        const mailOptions = {
          from: process.env.EMAIL_ADDRESS,
          to: emailDetails[EmailNotificationModel.recipientEmail],
          subject: emailDetails[EmailNotificationModel.subject],
          text: emailDetails[EmailNotificationModel.message],
        };
        let retrieveCount = emailDetails[EmailNotificationModel.retryCount];
        const isSent = await sendEmail(mailOptions, emailDetails, retrieveCount);
        if (isSent) {
          await sendEmail(mailOptions, emailDetails, retrieveCount + 1);
        }
      }
    }
  } catch (error) {
    logger.error(error, { file: __filename });
  }
};

export default checkAndSendEmail;
