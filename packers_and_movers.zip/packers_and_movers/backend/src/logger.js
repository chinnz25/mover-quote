import winston from "winston";
import dotenv from "dotenv";

dotenv.config();
dotenv.config({ path: `.env.${process.env.NODE_ENV}` });

const { createLogger, format, transports } = winston;
const { timestamp, combine, printf } = format;

const logFormat = printf(({ timestamp, level, message, file }) => {
  if (file === undefined) {
    return `\n[${level.toUpperCase()}] ${timestamp}\n${message}`;
  }
  return `\n${file}\n[${level.toUpperCase()}] ${timestamp}\n${message}`;
});

const logger = createLogger({
  level: process.env.LOG_LEVEL,
  format: combine(timestamp(), logFormat),
  transports: [
    new transports.Console(),
    new transports.File({
      filename: `${process.env.LOG_PATH}\\${process.env.LOG_FILE_NAME}`,
      maxsize: process.env.LOG_MAX_FILE_SIZE,
      maxFiles: process.env.LOG_MAX_FILE_COUNT,
    }),
  ],
});

export default logger;
