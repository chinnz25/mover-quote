import { fileURLToPath } from "url";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import { findById } from "../services/userService.js";
import logger from "../logger.js";
import { unauthorized, internalServerError } from "../utilities/apiResponse.js";

dotenv.config();
dotenv.config({ path: `.env.${process.env.NODE_ENV}` });

const __filename = fileURLToPath(import.meta.url);

const authenticateMiddleware = (req, res, next) => {
  let resObj;
  let jwtToken;
  const authHeader = req.headers.authorization;
  if (authHeader !== undefined) {
    jwtToken = authHeader.split(" ")[1];
  }
  if (jwtToken === undefined) {
    logger.info("JWT is undefined", { file: __filename });
    resObj = unauthorized();
    res.status(resObj.resultCode).json(resObj);
  } else {
    jwt.verify(jwtToken, process.env.IDENTITY_JWT_KEY, async (error, payload) => {
      try {
        if (error) {
          logger.info(error, { file: __filename });
          resObj = unauthorized();
          res.status(resObj.resultCode).json(resObj);
        } else {
          let user = await findById(payload.userId);
          if (!user.status) {
            logger.info("User id not found", { file: __filename });
            resObj = unauthorized("User id not found");
            res.status(resObj.resultCode).json(resObj);
          } else if (user.data.isActive == false) {
            logger.info("User is temporarily unauthenticated", { file: __filename });
            resObj = unauthorized("User is temporarily unauthenticated");
            res.status(resObj.resultCode).json(resObj);
          } else {
            logger.info("User details : " + JSON.stringify(user.data), { file: __filename });
            req.userDetails = user.data;
            next();
          }
        }
      } catch (error) {
        logger.error(error, { file: __filename });
        resObj = internalServerError();
        res.status(resObj.resultCode).json(resObj);
      }
    });
  }
};

export default authenticateMiddleware;
