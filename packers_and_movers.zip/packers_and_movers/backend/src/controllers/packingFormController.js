import { fileURLToPath } from "url";
import { badRequest, internalServerError, success } from "../utilities/apiResponse.js";
import logger from "../logger.js";
import { sendEmailWithPDF } from "../services/emailNotificationService.js";
import axios from "axios";

const __filename = fileURLToPath(import.meta.url);

const headers = {
    'x-rapidapi-key': '6bcea8b5c0msh96af5e9aae00e5ep1303e7jsnb417711e1ff5',
    'x-rapidapi-host': 'place-autocomplete1.p.rapidapi.com'
};

export const postPackingDetails = async (req, res) => {
    let resObj;
    try {
        let param = req.body;
        logger.info("Request reached postPackingDetails, body : " + JSON.stringify(req.body), { file: __filename });
        if (param.name === "" || param.name === null) {
            resObj = badRequest("Name is required");
        } else if (param.email === "" || param.email === null) {
            resObj = badRequest("Email is required");
        } else {
            let res = sendEmailWithPDF(param);
            resObj = success(res);
        }
    } catch (error) {
        logger.error(error, { file: __filename });
        resObj = internalServerError();
    }
    logger.info("Response body : " + JSON.stringify(resObj), { file: __filename });
    res.status(resObj.resultCode).json(resObj);
}

export const getLocation = async (req, res) => {
    let resObj;
    try {
        const { input, radius } = req.body;

        const response = await axios.get(`https://place-autocomplete1.p.rapidapi.com/autocomplete/json?input=${input}&radius=${radius}`, {
            headers: headers
        })
        let data = response.data.predictions.length > 0 ? response.data.predictions.map(((location, index) => {
            return {
                label: location.description,
                value: location.place_id
            }
        })) : [];
        resObj = success(data);
    } catch (error) {
        logger.error(error, { file: __filename });
        resObj = internalServerError();
    }
    logger.info("Response body : " + JSON.stringify(resObj), { file: __filename });
    res.status(resObj.resultCode).json(resObj);
}