import React, { createRef, useRef } from "react";
import { Switch, Stack, styled, Autocomplete, Snackbar, TextField, Accordion, AccordionDetails, AccordionSummary, Grid, IconButton, Typography, Button, Paper, CircularProgress } from "@mui/material";
import { useState } from "react";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import { useFormik } from "formik";
import axios from "axios";
import * as Yup from "yup";
import formData from "./FormData.json";
import "./Form.css";

const CustomSwitch = styled(Switch)(({ theme }) => ({
    width: 42,
    height: 26,
    padding: 0,
    display: "flex",
    "&:active": {
        "& .MuiSwitch-thumb": {
            width: 22,
        },
        "& .MuiSwitch-switchBase.Mui-checked": {
            transform: "translateX(16px)",
        },
    },
    "& .MuiSwitch-switchBase": {
        padding: 1,
        "&.Mui-checked": {
            transform: "translateX(16px)",
            color: "#fff",
            "& + .MuiSwitch-track": {
                opacity: 1,
                backgroundColor: "#1976d2",
            },
        },
    },
    "& .MuiSwitch-thumb": {
        boxShadow: "0 2px 4px 0 rgba(0, 35, 11, 0.2)",
        width: 24,
        height: 24,
        borderRadius: 12,
        transition: theme.transitions.create(["width"], {
            duration: 200,
        }),
    },
    "& .MuiSwitch-track": {
        borderRadius: 13,
        opacity: 1,
        backgroundColor: theme.palette.mode === "dark" ? "#39393D" : "#E9E9EA",
        boxSizing: "border-box",
    },
}));


function PackersAndMoversForm() {
    const url = "http://127.0.0.1:3001/api/packing/";
    const [furnitureData, setFurnitureData] = useState(formData);
    const [filteredFurnitureData, setFilteredFurnitureData] = useState(formData);
    const [pickupLocations, setpickupLocations] = useState([]);
    const [dropLocations, setdropLocations] = useState([]);
    const [locationLoading, setLocationLoading] = useState(false);
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: "",
    });

    const roomRefs = useRef(furnitureData.reduce((acc, room) => {
        acc[room.room] = createRef();
        return acc;
    }, {}));

    const formik = useFormik({
        initialValues: {
            name: "",
            mobile: "",
            email: "",
            withinCity: false,
            serviceLiftAtPickup: false,
            serviceLiftAtDrop: false,
            singleLayer: false,
            multiLayer: false,
            unpacking: false,
            dismantling: false,
            pickupLocation: null,
            dropLocation: null,
            pickupFloor: "",
            dropFloor: "",
        },
        validationSchema: Yup.object({
            name: Yup.string()
                .required('Name is required'),
            mobile: Yup.string()
                .matches(/^[0-9]{10}$/, 'Mobile number must be 10 digits')
                .required('Mobile number is required'),
            email: Yup.string()
                .email('Invalid email address')
                .required('Email is required'),
            pickupLocation: Yup.object({
                value: Yup.string().required('Pickup location is required')
            }).required('Pickup location is required'),
            dropLocation: Yup.object({
                value: Yup.string().required('Drop location is required')
            }).required('Drop location is required'),
            pickupFloor: Yup.string()
                .required('Pickup floor is required'),
            dropFloor: Yup.string()
                .required('Drop floor is required')
        }),
        onSubmit: async (values, { resetForm }) => {
            let params = {
                name: values.name,
                email: values.email,
                mobile: values.mobile,
                serviceLiftAtPickup: values.serviceLiftAtPickup,
                serviceLiftAtDrop: values.serviceLiftAtDrop,
                pickupLocationDetails: {
                    pickupLocation: values.pickupLocation.label,
                    pickupFloor: values.pickupFloor
                },
                dropLocationDetails: {
                    dropLocation: values.dropLocation.label,
                    dropFloor: values.dropFloor
                },
                addOns: {
                    singleLayerPacking: values.singleLayer,
                    multiLayerPacking: values.multiLayer,
                    unpacking: values.unpacking,
                    dismantling: values.dismantling
                },
                furnitures: filteredFurnitureData
            }
            let res = await axios.post(url, params);
            if (res.data.status && res.data.message === "success") {
                setSnackbar({
                    open: true,
                    message: "Submitted successfully!"
                })
            } else {
                setSnackbar({
                    open: true,
                    message: "Something went wrong please try again!"
                })
            }
            resetForm();
        },
    });

    function filterFurniture(data) {
        const result = [];
        data.forEach(room => {
            room.furniture.forEach(furnitureType => {
                furnitureType.subtypes.forEach(furniture => {
                    if (furniture.quantity > 0) {
                        result.push({
                            name: furniture.name,
                            quantity: furniture.quantity,
                            price: furniture.price
                        });
                    }
                });
            });
        });
        return result;
    }

    const updateQuantity = (roomName, furnitureType, subtypeId, newQuantity) => {
        const updatedData = furnitureData.map((room) => {
            if (room.room === roomName) {
                const updatedFurniture = room.furniture.map((category) => {
                    if (category.type === furnitureType) {
                        const updatedSubtypes = category.subtypes.map((subtype) => {
                            if (subtype.id === subtypeId) {
                                return { ...subtype, quantity: newQuantity };
                            }
                            return subtype;
                        });
                        return { ...category, subtypes: updatedSubtypes };
                    }
                    return category;
                });
                return { ...room, furniture: updatedFurniture };
            }
            return room;
        });
        let filteredData = filterFurniture(updatedData);
        setFilteredFurnitureData(filteredData);
        setFurnitureData(updatedData);
    };

    const scrollToRoom = (roomName) => {
        roomRefs.current[roomName].current.scrollIntoView({ behavior: 'smooth' });
    };

    const handleSwitchChange = (event) => {

        // singleLayerPacking: values.singleLayer,
        //             multiLayerPacking: values.multiLayer,
        if (event.target.name === "singleLayer" && event.target.checked) {
            formik.setFieldValue("multiLayer", false);
        }
        if (event.target.name === "multiLayer" && event.target.checked) {
            formik.setFieldValue("singleLayer", false);
        }
        formik.setFieldValue(event.target.name, event.target.checked);
    };

    const pickupLocationChange = async (e) => {
        let params = {
            input: `India, ${e.target.value}`,
            radius: 500
        }
        let res = await axios.post(url + "location/", params);
        if (res.data.status && res.data.resultCode === 200) {
            setpickupLocations(res.data.data);
        }
    }

    const dropLocationChange = async (e) => {
        setLocationLoading(true);
        let params = {
            input: e.target.value,
            radius: 500
        }
        let res = await axios.post(url + "location/", params);
        if (res.data.status && res.data.resultCode === 200) {
            setdropLocations(res.data.data);
        }
        setLocationLoading(false);
    }

    return (
        <Grid container>
            <Grid item xs={0} md={4}></Grid>
            <Grid item xs={0} md={7}>
                <Paper elevation={3} sx={{ padding: 3, marginTop: 3, backgroundColor: 'transparent' }}>
                    <form onSubmit={formik.handleSubmit} className="details">
                        <Typography variant="h5" style={{ color: '#1976d2', textAlign: 'center' }}>
                            Top Packers and Movers in Coimbatore
                        </Typography>
                        <Typography style={{ color: '#ed823a', textAlign: 'center' }} gutterBottom>
                            Shifting hassles? Packers and Movers in Coimbatore has you covered! Move with ease starting at just Rs.1200.
                        </Typography>
                        <Grid sx={{ padding: '1rem', border: '1px solid #1976d2', borderRadius: '10px', marginBottom: '1rem' }}>
                            <Typography variant="h5" style={{ color: '#1976d2' }} gutterBottom>
                                Personal Details
                            </Typography>
                            <Grid container spacing={2}>
                                <Grid item xs={12} md={6}>
                                    <TextField
                                        fullWidth
                                        id="name"
                                        name="name"
                                        label="Name"
                                        value={formik.values.name}
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                        error={formik.touched.name && Boolean(formik.errors.name)}
                                        helperText={formik.touched.name && formik.errors.name}
                                    />
                                </Grid>
                                <Grid item xs={12} md={6}>
                                    <TextField
                                        fullWidth
                                        id="mobile"
                                        name="mobile"
                                        label="Mobile"
                                        value={formik.values.mobile}
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                        error={formik.touched.mobile && Boolean(formik.errors.mobile)}
                                        helperText={formik.touched.mobile && formik.errors.mobile}
                                    />
                                </Grid>
                                <Grid item xs={12} md={6}>
                                    <TextField
                                        fullWidth
                                        id="email"
                                        name="email"
                                        label="Email"
                                        value={formik.values.email}
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                        error={formik.touched.email && Boolean(formik.errors.email)}
                                        helperText={formik.touched.email && formik.errors.email}
                                    />
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid sx={{ padding: '1rem', border: '1px solid #1976d2', borderRadius: '10px' }}>
                            <Typography variant="h5" style={{ color: '#1976d2' }} gutterBottom>
                                Moving Details
                            </Typography>
                            {/* <div className="WithIn_city">
                                <Typography variant="h6">Within City</Typography>
                                <CustomSwitch
                                    name="withinCity"
                                    checked={formik.values.withinCity}
                                    onChange={handleSwitchChange}
                                    inputProps={{ "aria-label": "ant design" }}
                                />
                            </div> */}
                            <Grid container spacing={2}>
                                <Grid item xs={12} sm={6}>
                                    <Autocomplete
                                        options={pickupLocations}
                                        getOptionLabel={(option) => option.label}
                                        value={formik.values.pickupLocation}
                                        onChange={(e, value) => formik.setFieldValue("pickupLocation", value)}
                                        loading={locationLoading}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                name="pickupLocation"
                                                label="Pickup Location"
                                                variant="outlined"
                                                onChange={pickupLocationChange}
                                                onBlur={formik.handleBlur}
                                                error={formik.touched.pickupLocation && Boolean(formik.errors.pickupLocation)}
                                                helperText={formik.touched.pickupLocation && formik.errors.pickupLocation}
                                                InputProps={{
                                                    ...params.InputProps,
                                                    endAdornment: (
                                                        <>
                                                            {locationLoading ? <CircularProgress color="inherit" size={20} /> : null}
                                                            {params.InputProps.endAdornment}
                                                        </>
                                                    ),
                                                }}
                                                fullWidth
                                            />
                                        )}
                                    />
                                    <Grid item xs={12} md={12} display="flex" gap={2} sx={{ marginTop: '1rem' }}>
                                        <CustomSwitch
                                            name="serviceLiftAtPickup"
                                            checked={formik.values.serviceLiftAtPickup}
                                            onChange={handleSwitchChange}
                                            inputProps={{ "aria-label": "ant design" }}
                                        />
                                        <label style={{ marginRight: 16 }}>Service lift available at pickup</label>
                                    </Grid>
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <Autocomplete
                                        options={dropLocations}
                                        getOptionLabel={(option) => option.label}
                                        value={formik.values.dropLocation}
                                        onChange={(e, value) => formik.setFieldValue("dropLocation", value)}
                                        loading={locationLoading}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                name="dropLocation"
                                                label="Drop Location"
                                                variant="outlined"
                                                onChange={dropLocationChange}
                                                onBlur={formik.handleBlur}
                                                error={formik.touched.dropLocation && Boolean(formik.errors.dropLocation)}
                                                helperText={formik.touched.dropLocation && formik.errors.dropLocation}
                                                InputProps={{
                                                    ...params.InputProps,
                                                    endAdornment: (
                                                        <>
                                                            {locationLoading ? <CircularProgress color="inherit" size={20} /> : null}
                                                            {params.InputProps.endAdornment}
                                                        </>
                                                    ),
                                                }}
                                                fullWidth
                                            />
                                        )}
                                    />
                                    <Grid item xs={12} md={12} display="flex" gap={2} sx={{ marginTop: '1rem' }}>
                                        <CustomSwitch
                                            name="serviceLiftAtDrop"
                                            checked={formik.values.serviceLiftAtDrop}
                                            onChange={handleSwitchChange}
                                            inputProps={{ "aria-label": "ant design" }}
                                        />
                                        <label style={{ marginRight: 16 }}>Service lift available at drop</label>
                                    </Grid>
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField
                                        fullWidth
                                        id="pickupFloor"
                                        name="pickupFloor"
                                        label="Pickup Floor"
                                        value={formik.values.pickupFloor}
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                        error={formik.touched.pickupFloor && Boolean(formik.errors.pickupFloor)}
                                        helperText={formik.touched.pickupFloor && formik.errors.pickupFloor}
                                        type="number"
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField
                                        fullWidth
                                        id="dropFloor"
                                        name="dropFloor"
                                        label="Drop Floor"
                                        value={formik.values.dropFloor}
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                        error={formik.touched.dropFloor && Boolean(formik.errors.dropFloor)}
                                        helperText={formik.touched.dropFloor && formik.errors.dropFloor}
                                        type="number"
                                    />
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid sx={{ padding: '1rem', border: '1px solid #1976d2', borderRadius: '10px', marginTop: '1rem', marginBottom: '1rem' }}>
                            <Grid container spacing={2} sx={{ marginBottom: '1rem' }}>
                                {furnitureData.map((room) => (
                                    <Grid item key={room.room}>
                                        <Button variant="contained" onClick={() => scrollToRoom(room.room)}>
                                            {room.room}
                                        </Button>
                                    </Grid>
                                ))}
                            </Grid>
                            <Grid sx={{ padding: '1rem', border: '1px solid #1976d2', borderRadius: '10px', marginTop: '1rem', marginBottom: '1rem' }}>
                                <Typography style={{ color: '#1976d2' }} variant="h5" gutterBottom>
                                    Add Items
                                </Typography>
                                {furnitureData.map((room) => (
                                    <div key={room.room} ref={roomRefs.current[room.room]}>
                                        <Typography variant="h6" gutterBottom>
                                            {room.room}
                                        </Typography>
                                        {room.furniture.map((category) => (
                                            <Accordion key={category.type} sx={{ marginBottom: 2 }}>
                                                <AccordionSummary
                                                    expandIcon={<ArrowDropDownIcon />}
                                                    aria-controls="panel1a-content"
                                                    id="panel1a-header"
                                                >
                                                    <Typography>{category.type}</Typography>
                                                </AccordionSummary>
                                                <AccordionDetails>
                                                    {category.subtypes.map((subtype) => (
                                                        <div key={subtype.id} className="furn_div">
                                                            <Grid container spacing={2} alignItems="center">
                                                                <Grid item xs={6}>
                                                                    <Typography>{subtype.name}</Typography>
                                                                </Grid>
                                                                <Grid item xs={6}>
                                                                    <Stack direction="row" spacing={1} alignItems="center">
                                                                        <IconButton
                                                                            onClick={() =>
                                                                                updateQuantity(room.room, category.type, subtype.id, subtype.quantity - 1)
                                                                            }
                                                                            disabled={subtype.quantity <= 0}
                                                                            sx={{ color: '#d32f2f' }}
                                                                        >
                                                                            <RemoveIcon />
                                                                        </IconButton>
                                                                        <Typography>{subtype.quantity}</Typography>
                                                                        <IconButton
                                                                            onClick={() =>
                                                                                updateQuantity(room.room, category.type, subtype.id, subtype.quantity + 1)
                                                                            }
                                                                            sx={{ color: '#1976d2' }}
                                                                        >
                                                                            <AddIcon />
                                                                        </IconButton>
                                                                    </Stack>
                                                                </Grid>
                                                            </Grid>
                                                        </div>
                                                    ))}
                                                </AccordionDetails>
                                            </Accordion>
                                        ))}
                                    </div>
                                ))}
                            </Grid>
                        </Grid>
                        <Grid sx={{ padding: '1rem', border: '1px solid #1976d2', borderRadius: '10px', marginTop: '1rem', marginBottom: '1rem' }}>
                            <Typography variant="h5" style={{ color: '#1976d2' }} gutterBottom>
                                Recommended add ons for you
                            </Typography>
                            <Grid container>
                                <Grid item xs={12} md={6} display="flex" gap={2} sx={{ marginBottom: '1rem' }}>
                                    <CustomSwitch
                                        name="singleLayer"
                                        checked={formik.values.singleLayer}
                                        onChange={handleSwitchChange}
                                        inputProps={{ "aria-label": "ant design" }}
                                    />
                                    <label style={{ marginRight: 16 }}>Single Layer Packaging ₹799</label>
                                </Grid>
                                <Grid item xs={12} md={6} display="flex" gap={2} sx={{ marginBottom: '1rem' }}>
                                    <CustomSwitch
                                        name="multiLayer"
                                        checked={formik.values.multiLayer}
                                        onChange={handleSwitchChange}
                                        inputProps={{ "aria-label": "ant design" }}
                                    />
                                    <label style={{ marginRight: 16 }}>Multi Layer Packaging ₹1,599</label>
                                </Grid>
                                <Grid item xs={12} md={6} display="flex" gap={2} sx={{ marginBottom: '1rem' }}>
                                    <CustomSwitch
                                        name="unpacking"
                                        checked={formik.values.unpacking}
                                        onChange={handleSwitchChange}
                                        inputProps={{ "aria-label": "ant design" }}
                                    />
                                    <label style={{ marginRight: 16 }}>Unpacking ₹799</label>
                                </Grid>
                                <Grid item xs={12} md={6} display="flex" gap={2} sx={{ marginBottom: '1rem' }}>
                                    <CustomSwitch
                                        name="dismantling"
                                        checked={formik.values.dismantling}
                                        onChange={handleSwitchChange}
                                        inputProps={{ "aria-label": "ant design" }}
                                    />
                                    <label style={{ marginRight: 16 }}>Dismantling ₹799</label>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Button type="submit" variant="contained" color="primary" fullWidth>
                            Submit
                        </Button>
                    </form>
                </Paper>
            </Grid>
            <Grid item xs={0} md={1}></Grid>
            <Snackbar
                anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                open={snackbar.open}
                onClose={() => { setSnackbar({ ...snackbar, open: false }) }}
                message={snackbar.message}
            />
        </Grid>
    );
}

export default PackersAndMoversForm;
