import React from "react";
import PackersAndMoversForm from "./pages/Form/Form";
import { ThemeProvider } from "@emotion/react";
import theme from "./theme";
import appBackground from "./assets/images/appBackground.jpg";
import { Box } from "@mui/material";


function App() {
  return (
    <ThemeProvider theme={theme} >
      <Box
        sx={{
          position: "relative",
          minHeight: "100vh",
          "&::before": {
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
            backgroundAttachment: "fixed",
            backgroundImage: `url(${appBackground})`,
            zIndex: -1,
            opacity: 0.2,
          },
        }}
      >
        <PackersAndMoversForm />
      </Box>
    </ThemeProvider>
  )
}

export default App;
